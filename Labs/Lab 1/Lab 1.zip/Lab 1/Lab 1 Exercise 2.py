Exercise 2

def c_to_f (c):
    f = (c * (9/5)) + 32
    return (str (c) + " degrees celsius is: " + str(f) + " degrees in fahrenheit")

print ("c_to_f(0)")
print (c_to_f(0))
