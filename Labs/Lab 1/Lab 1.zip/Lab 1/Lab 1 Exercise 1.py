Exercise 1
x= int(input("Please enter first value: "))
y= int(input("Please enter second value: "))

intdiv = x//y
modulo = x%y

print ("The integer division is: " + str(intdiv))
print ("The remainder is: " + str(modulo))

